package uniandes.dpoo.aerolinea.persistencia;

import uniandes.dpoo.aerolinea.modelo.Aerolinea;

public class IPersistenciaAerolinea {

	public void cargarAerolinea(String archivo, Aerolinea aerolinea) {
		// TODO Auto-generated method stub
		
	}

	public void salvarAerolinea(String archivo, Aerolinea aerolinea) {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args) {
		IPersistenciaAerolinea
	}

}
